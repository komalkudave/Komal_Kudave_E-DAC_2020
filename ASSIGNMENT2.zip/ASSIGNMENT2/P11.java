import java.util.Scanner;
class P11{
 	public static void main (String args[])

{

Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int a=n-1;
for(int j=1;j<=n;j++)
{
System.out.print(n+" ");
}
System.out.println();
for(int i=1;i<=n;i++)
{
    for(int z=1;z<=i;z++)
    {
System.out.print(" ");
    }
for(int k=i;k<=n-1;k++)
{
System.out.print(a+" ");

}
a=a-1;
System.out.println();
}

}





}