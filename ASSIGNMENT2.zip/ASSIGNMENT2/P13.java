import java.util.Scanner;
class P13{
 	public static void main (String args[])

{

Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int a=n;//space
int z=n+2;
for(int i=1;i<=n;i++)
{
for(int j=1;j<=a;j++)
{

System.out.print("  ");

}

for(int k=i;k>1;k--)
{

System.out.print(n-k+1+" ");

}
a--;
for(int x=1;x<=i;x++)
{
System.out.print(n-x+1+" ");

}
System.out.println();





}
}}