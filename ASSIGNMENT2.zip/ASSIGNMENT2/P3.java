import java.util.*;
import java.util.Scanner;
class P3{
 	public static void main (String args[])

{

Scanner sc=new Scanner(System.in);
int n=sc.nextInt();

for(int i=1;i<=n;i++)
{
System.out.print("*");
}
System.out.println();
for(int j=1;j<=n-2;j++)
{
for(int c=j;c<=j;c++)
{
System.out.print("*");
for(int k=c+1;k<=n-2;k++)
{
System.out.print(" ");
}
System.out.print("*");
}
System.out.println();
}
for(int z=n;z<=n;z++)
{
System.out.print("*");
}
System.out.println();





}

}