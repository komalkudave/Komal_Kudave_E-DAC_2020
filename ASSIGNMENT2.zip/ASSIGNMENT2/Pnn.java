
import java.util.Scanner;
class Pnn{
 	public static void main (String args[])

{

Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int a=1;
int l=n-1;//spaces
for(int i=1;i<=n;i++)
{
    int z=0;
for(int j=1;j<=l;j++)
{

System.out.print("  ");


} 
 
 for(int k=1;k<=a;k++)
 {
    if(k<=i)
    {
    z=z+1;
    
    }
    else{
    z=z-1;
   
  }
    System.out.print(z+" ");
 }

 
System.out.println();
a=a+2;
l--;
}
}





}





